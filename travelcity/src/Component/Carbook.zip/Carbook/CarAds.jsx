
import React from 'react'

export const CarAds = () => {
  return (
    <div style={{width:"100%"}}> <br /><br /><br/>
        <img src="https://tpc.googlesyndication.com/simgad/5344954049543646736?" width="100%" alt="" /> <br /><br /><br />
        <img src="https://tpc.googlesyndication.com/simgad/283125829164638811?" width="100%" alt="" />
    </div>
  )
}